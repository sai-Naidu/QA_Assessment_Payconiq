package stepDefinitions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.Assert;

import com.jayway.jsonpath.JsonPath;
import com.payconiq.Services.HotelBookingServices;
import com.payconiq.Utils.CommonFunctions;
import com.payconiq.Utils.PayconiqLog;
import com.payconiq.Utils.ReportStorage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;

public class PartialUpdateBookingSteps {
	
	Response response;
	CommonFunctions cf = new CommonFunctions();
	HotelBookingServices hbs = new HotelBookingServices();
	Map<String, String> createBookingTestData;
	Map<String, String> partialUpdateTestData;
	String bookingId ;
	
	@Given("I send a valid request to getBookingIds endpoint for data creation")
	public void i_send_a_valid_request_to_get_booking_ids_endpoint_for_data_creation() throws Exception {
		response = hbs.sendRequestForGetBookingIds(null);
		ReportStorage.getScenario().log("Response : \r\n"+response.prettyPrint());
	}

	@Then("I store the bookingId from getBookingIds response")
	public void i_store_the_booking_id_from_get_booking_ids_response() {
		bookingId = JsonPath.read(response.getBody().asString(), "$[0].bookingid").toString();
		ReportStorage.getScenario().log("BookingId : "+bookingId);
	}
	
	@Then("I send a valid payload with a valid token to partialUpdateBooking endpoint")
	public void i_send_a_valid_payload_with_a_valid_token_to_partial_update_booking_endpoint() throws Exception {
		partialUpdateTestData = new HashMap<String, String>();
		partialUpdateTestData.put("Req_id", bookingId);
		partialUpdateTestData.put("Req_firstname", cf.generateRandomString(8));
		response = hbs.sendRequestForPartialUpdateBooking("YWRtaW46cGFzc3dvcmQxMjM=", partialUpdateTestData);
	}
	
	@Then("the response status code of partialUpdateBooking service should be {int}")
	public void the_response_status_code_of_partial_update_booking_service_should_be(Integer statusCode) {
		Assert.assertEquals(response.getStatusCode(), statusCode);
	}
	
	@Then("the response contentType of partialUpdateBooking service should be {string}")
	public void the_response_content_type_of_partial_update_booking_service_should_be(String message) {
		Assert.assertEquals(response.contentType(), message);
	}
	
	@Then("validate the response of partialUpdateBooking service")
	public void validate_the_response_of_partial_update_booking_service() {
		List<Boolean> status = new ArrayList<Boolean>();
		PayconiqLog.info("===============================================Response===========================================");
		ReportStorage.getScenario().log("Response : \r\n"+response.prettyPrint());
		cf.validateNodeValue(response, "firstname", partialUpdateTestData.get("Req_firstname"), "firstname", status);
		if(status.contains(false)) {
			Assert.fail("One or more errors found during Response validation. Please check the RED colored values");;
		}
	}
	
	@Then("I send a valid payload with multiple updates and with a valid token to partialUpdateBooking endpoint")
	public void i_send_a_valid_payload_with_multiple_updates_and_with_a_valid_token_to_partial_update_booking_endpoint() throws Exception {
		partialUpdateTestData = new HashMap<String, String>();
		partialUpdateTestData.put("Req_id", bookingId);
		partialUpdateTestData.put("Req_checkout", cf.addDaysToTheDate(cf.getCurrentDate(), "15"));
		partialUpdateTestData.put("Req_additionalneeds", "Dinner Only");
		response = hbs.sendRequestForPartialUpdateBooking("YWRtaW46cGFzc3dvcmQxMjM=", partialUpdateTestData);
	}
	
	@Then("validate the response of partialUpdateBooking service with multiple updates")
	public void validate_the_response_of_partial_update_booking_service_with_multiple_updates() {
		List<Boolean> status = new ArrayList<Boolean>();
		PayconiqLog.info("===============================================Response===========================================");
		ReportStorage.getScenario().log("Response : \r\n"+response.prettyPrint());
		cf.validateNodeValue(response, "bookingdates.checkout", partialUpdateTestData.get("Req_checkout"), "checkout", status);
		cf.validateNodeValue(response, "additionalneeds", partialUpdateTestData.get("Req_additionalneeds"), "additionalneeds", status);
		if(status.contains(false)) {
			Assert.fail("One or more errors found during Response validation. Please check the RED colored values");;
		}
	}
	
	@Given("I send a request with a valid token and invalid booking id={int} to partialUpdateBooking endpoint")
	public void i_send_a_request_with_a_valid_token_and_invalid_booking_id_to_partial_update_booking_endpoint(Integer id) throws Exception {
		partialUpdateTestData = new HashMap<String, String>();
		partialUpdateTestData.put("Req_id", String.valueOf(id));
		partialUpdateTestData.put("Req_additionalneeds", "Dinner Only");
		response = hbs.sendRequestForPartialUpdateBooking("YWRtaW46cGFzc3dvcmQxMjM=", partialUpdateTestData);
	}
	
	@Then("the response of partialUpdateBooking service should be {string}")
	public void the_response_of_partial_update_booking_service_should_be(String message) {
		ReportStorage.getScenario().log("Response : \r\n"+response.prettyPrint());
		Assert.assertEquals(response.getBody().asString(), message);
	}
	
	@Then("I send a valid payload with invalid token to partialUpdateBooking endpoint")
	public void i_send_a_valid_payload_with_invalid_token_to_partial_update_booking_endpoint() throws Exception {
		partialUpdateTestData = new HashMap<String, String>();
		partialUpdateTestData.put("Req_id", bookingId);
		partialUpdateTestData.put("Req_firstname", cf.generateRandomString(8));
		response = hbs.sendRequestForPartialUpdateBooking("abcd1234", partialUpdateTestData);
	}
	
	@Then("I send a valid payload with valid token and valid booking id and invalid request")
	public void i_send_a_valid_payload_with_valid_token_and_valid_booking_id_and_invalid_request() throws Exception {
		partialUpdateTestData = new HashMap<String, String>();
		partialUpdateTestData.put("Req_id", bookingId);
		partialUpdateTestData.put("Req_depositpaid", "false+");
		response = hbs.sendRequestForPartialUpdateBooking("YWRtaW46cGFzc3dvcmQxMjM=", partialUpdateTestData);
	}
}
