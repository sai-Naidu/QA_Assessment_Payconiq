package stepDefinitions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.payconiq.Services.HotelBookingServices;
import com.payconiq.Utils.CommonFunctions;
import com.payconiq.Utils.PayconiqLog;
import com.payconiq.Utils.ReportStorage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;

import org.testng.Assert;

public class CreateBookingSteps {
	Response response;
	CommonFunctions cf = new CommonFunctions();
	HotelBookingServices hbs = new HotelBookingServices();
	Map<String, String> testData;
	
	@Given("I send a valid payload to createBooking endpoint")
	public void i_send_a_valid_payload_to_create_booking_endpoint() throws Exception {
		testData = new HashMap<String, String>();
		testData.put("Req_firstname", cf.generateRandomString(8));
		testData.put("Req_lastname", cf.generateRandomString(7));
		testData.put("Req_totalprice", cf.generateRandomInteger(3));
		testData.put("Req_depositpaid", "true");
		testData.put("Req_checkin", cf.addDaysToTheDate(cf.getCurrentDate(), "2"));
		testData.put("Req_checkout", cf.addDaysToTheDate(cf.getCurrentDate(), "30"));
		testData.put("Req_additionalneeds", "Breakfast and Lunch");
		response = hbs.sendRequestForCreateBooking(testData);
	}

	@Then("the response status code should be {int}")
	public void the_response_status_code_should_be(Integer statuscode) {
	    Assert.assertEquals(response.getStatusCode(), statuscode);
	}
	
	@Then("the response contentType should be {string}")
	public void the_response_content_type_should_be(String message) {
		Assert.assertEquals(response.contentType(), message);
	}

	@Then("validate the response")
	public void validate_the_response() {
		List<Boolean> status = new ArrayList<Boolean>();
		PayconiqLog.info("===============================================Response===========================================");
		ReportStorage.getScenario().log("Response : \r\n"+response.prettyPrint());
		cf.validateNodeValue(response, "booking.firstname", testData.get("Req_firstname"), "firstname", status);
		cf.validateNodeValue(response, "booking.lastname", testData.get("Req_lastname"), "lastname", status);
		cf.validateNodeValue(response, "booking.totalprice", testData.get("Req_totalprice"), "totalprice", status);
		cf.validateNodeValue(response, "booking.depositpaid", testData.get("Req_depositpaid"), "depositpaid", status);
		cf.validateNodeValue(response, "booking.bookingdates.checkin", testData.get("Req_checkin"), "checkin", status);
		cf.validateNodeValue(response, "booking.bookingdates.checkout", testData.get("Req_checkout"), "checkout", status);
		cf.validateNodeValue(response, "booking.additionalneeds", testData.get("Req_additionalneeds"), "additionalneeds", status);
		if(status.contains(false)) {
			Assert.fail("One or more errors found during Response validation. Please check the RED colored values");;
		}
	}
	
	@Given("I send a payload to createBooking endpoint")
	public void i_send_a_payload_to_create_booking_endpoint() throws Exception {
		testData = new HashMap<String, String>();
		testData.put("Req_firstname", cf.generateRandomString(8));
		testData.put("Req_lastname", cf.generateRandomString(7));
		testData.put("Req_totalprice", cf.generateRandomInteger(3));
		testData.put("Req_checkin", cf.addDaysToTheDate(cf.getCurrentDate(), "2"));
		testData.put("Req_checkout", cf.addDaysToTheDate(cf.getCurrentDate(), "30"));
		testData.put("Req_additionalneeds", "Breakfast and Lunch");
		response = hbs.sendRequestForCreateBooking(testData);
	}

	@Then("the response should be {string}")
	public void the_response_should_be(String message) {
		ReportStorage.getScenario().log("Response : \r\n"+response.prettyPrint());
		Assert.assertEquals(response.getBody().asString(), message);
	}
	
	@Given("I send an invalid payload to createBooking endpoint")
	public void i_send_an_invalid_payload_to_create_booking_endpoint() throws Exception {
		testData = new HashMap<String, String>();
		testData.put("Req_firstname", cf.generateRandomString(8));
		testData.put("Req_lastname", cf.generateRandomString(7));
		testData.put("Req_totalprice", cf.generateRandomInteger(3));
		testData.put("Req_depositpaid", "false,");
		testData.put("Req_checkin", cf.addDaysToTheDate(cf.getCurrentDate(), "2"));
		testData.put("Req_checkout", cf.addDaysToTheDate(cf.getCurrentDate(), "30"));
		testData.put("Req_additionalneeds", "Breakfast and Lunch");
		response = hbs.sendRequestForCreateBooking(testData);
	}

}
