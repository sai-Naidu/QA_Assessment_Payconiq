package stepDefinitions;

import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;

import com.jayway.jsonpath.JsonPath;
import com.payconiq.Services.HotelBookingServices;
import com.payconiq.Utils.CommonFunctions;
import com.payconiq.Utils.ReportStorage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;

public class DeleteBookingSteps {
	
	Response response;
	CommonFunctions cf = new CommonFunctions();
	HotelBookingServices hbs = new HotelBookingServices();
	Map<String, String> deleteBookingTestData;
	String bookingId ;
	
	@Given("I send a valid request to getBookingIds endpoint for test data creation")
	public void i_send_a_valid_request_to_get_booking_ids_endpoint_for_test_data_creation() throws Exception {
		response = hbs.sendRequestForGetBookingIds(null);
		ReportStorage.getScenario().log("Response : \r\n"+response.prettyPrint());
	}

	@Then("I store the bookingId from getBookingIds json response")
	public void i_store_the_booking_id_from_get_booking_ids_json_response() {
		bookingId = JsonPath.read(response.getBody().asString(), "$[0].bookingid").toString();
		ReportStorage.getScenario().log("BookingId : "+bookingId);
	}
	
	@Then("I send a request with a valid token and valid booking id to deleteBooking endpoint")
	public void i_send_a_request_with_a_valid_token_and_valid_booking_id_to_delete_booking_endpoint() throws Exception {
		deleteBookingTestData = new HashMap<String, String>();
		deleteBookingTestData.put("Req_id", bookingId);
		response = hbs.sendRequestForDeleteBooking("YWRtaW46cGFzc3dvcmQxMjM=", deleteBookingTestData);
	}
	
	@Then("the response status code of deleteBooking service should be {int}")
	public void the_response_status_code_of_delete_booking_service_should_be(Integer statusCode) {
		Assert.assertEquals(response.getStatusCode(), statusCode);
	}
	
	@Then("the response contentType of deleteBooking service should be {string}")
	public void the_response_content_type_of_delete_booking_service_should_be(String message) {
		Assert.assertEquals(response.contentType(), message);
	}
	
	@Then("the response of deleteBooking service should be {string}")
	public void the_response_of_delete_booking_service_should_be(String message) {
		ReportStorage.getScenario().log("Response : \r\n"+response.prettyPrint());
		Assert.assertEquals(response.getBody().asString(), message);
	}
	
	@Then("I send a request with a invalid token and valid booking id to deleteBooking endpoint")
	public void i_send_a_request_with_a_invalid_token_and_valid_booking_id_to_delete_booking_endpoint() throws Exception {
		deleteBookingTestData = new HashMap<String, String>();
		deleteBookingTestData.put("Req_id", bookingId);
		response = hbs.sendRequestForDeleteBooking("abcd1234", deleteBookingTestData);
	}
	
	@Given("I send a request with valid token and invalid booking id to deleteBooking endpoint")
	public void i_send_a_request_with_valid_token_and_invalid_booking_id_to_delete_booking_endpoint() throws Exception {
		deleteBookingTestData = new HashMap<String, String>();
		deleteBookingTestData.put("Req_id", "1500");
		response = hbs.sendRequestForDeleteBooking("YWRtaW46cGFzc3dvcmQxMjM=", deleteBookingTestData);
	}

}
