package stepDefinitions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.Assert;

import com.jayway.jsonpath.JsonPath;
import com.payconiq.Services.HotelBookingServices;
import com.payconiq.Utils.CommonFunctions;
import com.payconiq.Utils.ReportStorage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;

public class GetBookingIds {
	
	Response response;
	CommonFunctions cf = new CommonFunctions();
	HotelBookingServices hbs = new HotelBookingServices();
	Map<String, String> createBookingTestData;
	Map<String, String> getBookingIdsTestData;
	String bookingId ;
	int countBefore;
	String firstName;
	String lastName;
	String checkin;
	String checkout;
	
	@Given("I send a valid request to getBookingIds endpoint without any parameters")
	public void i_send_a_valid_request_to_get_booking_ids_endpoint_without_any_parameters() throws Exception {
		response = hbs.sendRequestForGetBookingIds(null);
		ReportStorage.getScenario().log("Response : \r\n"+response.prettyPrint());
	}

	@Then("I store the count of bookingIds")
	public void i_store_the_count_of_booking_ids() {
		countBefore = response.jsonPath().getList("$").size();
		System.out.println(countBefore);
	}
	
	@Then("I send a valid request to createBooking service")
	public void i_send_a_valid_request_to_create_booking_service() throws Exception {
		createBookingTestData = new HashMap<String, String>();
		createBookingTestData.put("Req_firstname", cf.generateRandomString(8));
		createBookingTestData.put("Req_lastname", cf.generateRandomString(7));
		createBookingTestData.put("Req_totalprice", cf.generateRandomInteger(3));
		createBookingTestData.put("Req_depositpaid", "true");
		createBookingTestData.put("Req_checkin", cf.addDaysToTheDate(cf.getCurrentDate(), "2"));
		createBookingTestData.put("Req_checkout", cf.addDaysToTheDate(cf.getCurrentDate(), "30"));
		createBookingTestData.put("Req_additionalneeds", "Breakfast and Lunch");
		response = hbs.sendRequestForCreateBooking(createBookingTestData);
		ReportStorage.getScenario().log("Response : \r\n"+response.prettyPrint());
	}
	
	@Then("I store the value of bookingId from createBooking response")
	public void i_store_the_value_of_booking_id_from_create_booking_response() {
		bookingId = response.jsonPath().getString("bookingid");
		ReportStorage.getScenario().log("BookingId : "+bookingId);
	}
	
	@Then("the response status code of getBookingIds service should be {int}")
	public void the_response_status_code_of_get_booking_ids_service_should_be(Integer statuscode) {
		Assert.assertEquals(response.getStatusCode(), statuscode);
	}
	
	@Then("the response contentType of getBookingIds service should be {string}")
	public void the_response_content_type_of_get_booking_ids_service_should_be(String message) {
		Assert.assertEquals(response.contentType(), message);
	}
	
	@Then("validate the response of getBookingIds service")
	public void validate_the_response_of_get_booking_ids_service() {
		List<Boolean> status = new ArrayList<Boolean>();
	    String responseBody = response.getBody().asString();
	    cf.validateValueInResponse(responseBody, "\"bookingid\": "+bookingId, status);
	    if(status.contains(false)) {
			Assert.fail("One or more errors found during Response validation. Please check the RED colored values");;
		}
	    
	}
	
	@Then("I send a valid request to getBookingIds endpoint with firstName and lastName parameters")
	public void i_send_a_valid_request_to_get_booking_ids_endpoint_with_first_name_and_last_name_parameters() throws Exception {
		getBookingIdsTestData = new HashMap<String, String>();
		getBookingIdsTestData.put("Req_param_1", "firstname");
		getBookingIdsTestData.put("Req_value_1", firstName);
		getBookingIdsTestData.put("Req_param_2", "lastname");
		getBookingIdsTestData.put("Req_value_2", lastName);
		response = hbs.sendRequestForGetBookingIds(getBookingIdsTestData);
		ReportStorage.getScenario().log("Response : \r\n"+response.prettyPrint());
	}
	
	@Then("validate the count of bookingIds")
	public void validate_the_count_of_booking_ids() {
		List<Boolean> status = new ArrayList<Boolean>();
		int countAfter = response.jsonPath().getList("$").size();
	    cf.genericAssertion(String.valueOf(countAfter), String.valueOf((countBefore+1)), "count of bookingIds", status);
	    if(status.contains(false)) {
			Assert.fail("One or more errors found during Response validation. Please check the RED colored values");;
		}
	}
	
	@Then("I store the value of bookingId from getBookingIds response")
	public void i_store_the_value_of_booking_id_from_get_booking_ids_response() {
		bookingId = JsonPath.read(response.getBody().asString(), "$[0].bookingid").toString();
		ReportStorage.getScenario().log("BookingId : "+bookingId);
	}

	@Then("I send a request to getBooking endpoint and store required parameters")
	public void i_send_a_request_to_get_booking_endpoint_and_store_required_parameters() throws Exception {
		Map<String, String> getBookingTestData = new HashMap<String, String>();
		getBookingTestData.put("Req_id", bookingId);
		response = hbs.sendRequestForGetBooking(getBookingTestData);
		firstName = response.jsonPath().getString("firstname"); 
		lastName = response.jsonPath().getString("lastname");
		checkin = response.jsonPath().getString("bookingdates.checkin");
		checkout = response.jsonPath().getString("bookingdates.checkout");
	}
	
	@Then("I send a valid request to getBookingIds endpoint with checkin and checkout parameters")
	public void i_send_a_valid_request_to_get_booking_ids_endpoint_with_checkin_and_checkout_parameters() throws Exception {
		getBookingIdsTestData = new HashMap<String, String>();
		getBookingIdsTestData.put("Req_param_1", "checkin");
		getBookingIdsTestData.put("Req_value_1", checkin);
		getBookingIdsTestData.put("Req_param_2", "checkout");
		getBookingIdsTestData.put("Req_value_2", checkout);
		response = hbs.sendRequestForGetBookingIds(getBookingIdsTestData);
		ReportStorage.getScenario().log("Response : \r\n"+response.prettyPrint());
	}




}
