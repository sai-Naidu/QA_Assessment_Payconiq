package hooks;

import com.payconiq.Utils.ReportStorage;

import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class ServiceHooks {
	
	@Before(order = 1)
    public void getScenario(Scenario scenario) {
		ReportStorage.putScenario(scenario);
    }
}
