package com.payconiq.Utils;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.RandomStringUtils;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class CommonFunctions {
	
	/**
	 * This is a common function to send a request to particular endpoint
	 * @param method : accepts method names like GET,POST,PUT,DELETE and PATCH
	 * @param token : accepts the token for authorization
	 * @param header : accepts the request headers in header1=value1,header2=value2 etc
	 * @param testData : accepts the test data in key value pairs. Key should starts with Req_
	 * @param fileName : accepts parameterized json or xml file name of the request
	 * @param url : accepts service url
	 * @return the response object
	 * @throws Exception
	 */
	public Response SendRequest(String method, String token, String header, Map<String,String> testData, String fileName, String url) throws Exception{
        Response response = null;
        Map<String, String> headerMap = new HashMap<String,String>();
        String requestBody="";
        try{
              if(url.contains("Req")){
                  url=generatePayload(testData, url);
              }
              PayconiqLog.info("===============================================URL===============================================");
              PayconiqLog.info(url);
              ReportStorage.getScenario().log("Url : "+url);
              if(fileName!=null){
            	  requestBody=generatePayload(testData, fileName);
            	  PayconiqLog.info("===============================================Request===========================================");
            	  PayconiqLog.info(requestBody);
            	  ReportStorage.getScenario().log("Request :\r\n"+requestBody);
              }
              if(header!=null) {
            	  headerMap = stringToMap(header);
              }
              if(!(token==null||token.isEmpty()||token.equals(""))){
            	  headerMap.put("Authorization", "Basic "+token);
              }
              RestAssured.urlEncodingEnabled=true;
              if(method.equalsIgnoreCase("GET")){
            	  if(header!=null) {
            		  response=RestAssured.given().headers(headerMap).get(url);
            	  }
            	  else {
            		  response=RestAssured.given().get(url);
            	  }
              }
              else if(method.equalsIgnoreCase("POST")){
            	  response = RestAssured.given().headers(headerMap).body(requestBody).post(url);    
              }
              else if(method.equalsIgnoreCase("PUT")){
            	  response=RestAssured.given().headers(headerMap).body(requestBody).put(url);
              }
              else if(method.equalsIgnoreCase("DELETE")){
            	  response=RestAssured.given().headers(headerMap).body(requestBody).delete(url);
              }
              else if(method.equalsIgnoreCase("PATCH")){
            	  response=RestAssured.given().headers(headerMap).body(requestBody).patch(url);
              }
        }
        catch(Exception ex){
        	ex.printStackTrace();
        }
		return response;
	}
	
	/**
	 * This method is used convert a string into key value pairs
	 * @param str : accepts comma separated strings in key=value format
	 * @return a map of keys and values
	 * @throws Exception
	 */
	public Map<String,String> stringToMap(String str) throws Exception{
		Map<String, String> map = new HashMap<String,String>();
		str=str.replaceAll("\\s+", "");
		String input[] = str.split(",");
		for(int i=0;i<input.length;i++){
			String key = input[i].split("=")[0];
			String value = input[i].split("=")[1];
			map.put(key.replaceAll("\\s+", ""), value.replaceAll("\\s+", ""));
		}
		return map;
	}
	
	/**
	 * This method is used to generate the json or xml payload. It is also used to generate a proper url from parameterized url
	 * @param testData : accepts the test data in key value pairs. Key should starts with Req_
	 * @param fileName : accepts parameterized url or json or xml file name of the request
	 * @return the payload or url
	 * @throws Exception
	 */
	public String generatePayload(Map<String,String> testData, String fileName) throws Exception{
		String payLoad = "";
		String filePath = System.getProperty("user.dir")+"//requestFiles//"+fileName;
		try {
			if(fileName.endsWith(".xml")||fileName.endsWith(".json")){
				payLoad = new String(Files.readAllBytes(Paths.get(filePath)));
			}
			else {
				payLoad=fileName;
			}
			if(testData!=null&&testData.size()!=0){
				Set<String> testDataKeys = testData.keySet();
				for(String key:testDataKeys){
					if(payLoad.contains(key)){
						payLoad=payLoad.replace("${"+key+"}", testData.get(key));
					}
				}
			}
		}
		catch (Exception ex){
			
		}
		payLoad=jsonBuilder(payLoad);
		return payLoad;
	}
	
	
	/**
	 * This method is used to generate random string with specified length
	 * @param numberOfChars : accepts the requred length of string
	 * @return random string
	 */
	public String generateRandomString(int numberOfChars) {
		String generatedString = RandomStringUtils.randomAlphabetic(numberOfChars);
		return generatedString;
	}
	
	/**
	 * This method is used to generate random Numeric String with specified length
	 * @param numberOfDigits : accepts the requred length of string
	 * @return random Numeric String
	 */
	public String generateRandomInteger(int numberOfDigits) {
		String generatedString="";
		boolean flag=true;
		while(flag) {
			generatedString = RandomStringUtils.randomNumeric(numberOfDigits);
			if(!generatedString.startsWith("0")) {
				flag=false;
			}
		}
		return generatedString;
	}
	
	/**
	 * This method is used to get current date in yyyy-MM-dd format
	 */
	public String getCurrentDate() {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Date dateobj = new Date();
		return df.format(dateobj);
	}
	
	/**
	 * This method is used to add required number of days to a particular date
	 * @param date : accept a date in yyyy-MM-dd format
	 * @param daysToAdd : number of days to add
	 * @return a date in yyyy-MM-dd format
	 */
	public String addDaysToTheDate(String date, String daysToAdd)  {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar c = Calendar.getInstance();
		try {
			c.setTime(sdf.parse(date));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		c.add(Calendar.DAY_OF_MONTH, Integer.parseInt(daysToAdd)); 
		String newDate = sdf.format(c.getTime());
		return newDate;
	}
	
	/**
	 * This method is to append the series of strings
	 * @param inputParams
	 * @return a string
	 */
	public String appendString(String[] inputParams){
    	StringBuilder finalStringBuilder= new StringBuilder("");
    	for(String s:inputParams){
     	   if(!s.equals("")){
     	       finalStringBuilder.append(s).append(System.getProperty("line.separator"));
     	    }
     	}
    	return finalStringBuilder.toString();
    }
    
	/**
	 * This method is used to create a partial json from a full josn with given parameters
	 * @param inputParams
	 * @return a json string
	 */
    public String jsonBuilder(String... inputParams){
    	String data=inputParams[0];
    	String[] lines = data.split(System.getProperty("line.separator"));
    	for(int i=0;i<lines.length;i++){
    		if(lines[i].contains("Req_")){
    	    	lines[i]="";
    	    }
    	    
    	}
    	data=appendString(lines);
    	lines=data.split(System.getProperty("line.separator"));
    	for(int i=0;i<lines.length;i++){
    		if(lines[i].contains("\"null\"")){
    	        lines[i]="";
    	    }
    	}
    	
    	data=appendString(lines);
    	lines=data.split(System.getProperty("line.separator"));
    	for(int i=0;i<lines.length;i++){
    	    if(lines[i].endsWith(",")&&lines[i+1].contains("}")){
    	    	lines[i]=lines[i].substring(0, lines[i].length()-1);
    	    }  
    	    if(lines[i].endsWith(": ")&&lines[i+1].contains("}")){
    	    	lines[i]="";
    	    	lines[i+1]="";
    	    }
    	}
    	data=appendString(lines);
    	lines=data.split(System.getProperty("line.separator"));
    	for(int i=0;i<lines.length;i++){
    	    if(lines[i].contains("{")&&lines[i+1].contains("}")){
    	        lines[i]="";
    	        lines[i+1]="";
    	        data=appendString(lines);
    	        lines=data.split(System.getProperty("line.separator"));
        	    i=0;
    	    }
    	    
    	}
    	
    	data=appendString(lines);
    	lines=data.split(System.getProperty("line.separator"));
    	for(int i=0;i<lines.length;i++){
    	    if(lines[i].endsWith(",")&&lines[i+1].contains("}")){
    	    	lines[i]=lines[i].substring(0, lines[i].length()-1);
    	    }
    	    if(lines[i].endsWith("},")&&lines[i+1].contains("}")){
    	    	lines[i]=lines[i].substring(0, lines[i].length()-1);
    	    }
    	}
    	
    	return appendString(lines);
    }
    
    /**
     * This method is used to validate a json node from a json response
     * @param response : accepts a json response from an endpoint
     * @param jsonPath : accepts a json Path
     * @param expected : accepts expectd value
     * @param parameter : accepts a parameter name for comparison
     * @param status : determines the status of a step as pass or fail
     */
    public void validateNodeValue(Response response, String jsonPath, String expected, String parameter, List<Boolean> status) {
    	String noError = "<font color=\"#32CD32\"><b>noError</b></font>";
		String error = "<font color=\"red\"><b>error</b></font>";
    	String result = "";
    	String actual = response.jsonPath().getString(jsonPath);
    	if(actual==null) {
			actual="null";
		}
    	if(expected.equals(actual)) {
    		status.add(true);
    		result = "Expected and Actual value of "+parameter+" = "+noError.replace("noError", actual);
    		PayconiqLog.info("===============================================Result===========================================");
    		ReportStorage.getScenario().log(result);
    	}
    	else {
    		status.add(false);
    		result = "Expected "+parameter+" = "+noError.replace("noError", expected)+" . But actual value = "+error.replace("error", actual);
    		PayconiqLog.info("===============================================Result===========================================");
    		ReportStorage.getScenario().log(result);
    	}
    }
    
    /**
     * This method is used to check if the expected value is present in a response string or not
     * @param str : accepts a string
     * @param expected : accepts a string of expected value
     * @param status : determines the status of a step as pass or fail
     */
    public void validateValueInResponse(String str, String expected, List<Boolean> status) {
    	String noError = "<font color=\"#32CD32\"><b>noError</b></font>";
		String error = "<font color=\"red\"><b>error</b></font>";
    	String result = "";
    	if(str.contains(expected)) {
    		status.add(true);
    		result = "Expected value = "+noError.replace("noError", expected)+" is present in response";
    		PayconiqLog.info("===============================================Result===========================================");
    		ReportStorage.getScenario().log(result);
    	}
    	else {
    		status.add(false);
    		result = "Expected value = "+error.replace("error", expected)+" is not present in response";
    		PayconiqLog.info("===============================================Result===========================================");
    		ReportStorage.getScenario().log(result);
    	}
    }
    
    /**
     * 
     * @param actual : accepts a string for comparison
     * @param expected : accepts expectd value
     * @param parameter : accepts a parameter name for comparison
     * @param status : determines the status of a step as pass or fail
     */
    public void genericAssertion(String actual, String expected, String parameter, List<Boolean> status) {
    	String noError = "<font color=\"#32CD32\"><b>noError</b></font>";
		String error = "<font color=\"red\"><b>error</b></font>";
    	String result = "";
    	if(expected.equals(actual)) {
    		status.add(true);
    		result = "Expected and Actual value of "+parameter+" = "+noError.replace("noError", actual);
    		PayconiqLog.info("===============================================Result===========================================");
    		ReportStorage.getScenario().log(result);
    	}
    	else {
    		status.add(false);
    		result = "Expected "+parameter+" = "+noError.replace("noError", expected)+" . But actual value = "+error.replace("error", actual);
    		PayconiqLog.info("===============================================Result===========================================");
    		ReportStorage.getScenario().log(result);
    	}
    }
        
	

}
