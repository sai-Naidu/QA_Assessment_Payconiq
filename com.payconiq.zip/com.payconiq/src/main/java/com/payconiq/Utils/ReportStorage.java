package com.payconiq.Utils;

import java.util.HashMap;

import io.cucumber.java.Scenario;

/**
 * This class is used to store data in report at runtime
 * @author hemasundarsai.n
 *
 */
public class ReportStorage {
	private static final HashMap<Thread, Scenario> map = new HashMap<>();

    public static void putScenario(Scenario scenario) {
        map.put(Thread.currentThread(), scenario);
    }

    public static Scenario getScenario() {
        return map.get(Thread.currentThread());
    }

}


