package com.payconiq.Services;

import java.util.Map;

import com.payconiq.Utils.CommonFunctions;

import io.restassured.response.Response;

public class HotelBookingServices {
	
	String baseUrl = "https://restful-booker.herokuapp.com/booking";
	CommonFunctions cf = new CommonFunctions();
	
	/**
	 * This method is to send request for CreateBooking service
	 * @param createBookingTestData : accepts the test data in key,value pairs and Key should starts with Req_
	 * @return Response object
	 * @throws Exception
	 */
	public Response sendRequestForCreateBooking(Map<String, String> createBookingTestData) throws Exception {
		String header = "Content-Type=application/json,Accept=application/json";
		Response response = cf.SendRequest("POST", null, header, createBookingTestData, "createBooking.json", baseUrl);
		return response;
	}
	
	/**
	 * This method is to send request for GetBooking service
	 * @param getBookingTestData : accepts the test data in key,value pairs and Key should starts with Req_
	 * @return Response object
	 * @throws Exception
	 */
	public Response sendRequestForGetBooking(Map<String, String> getBookingTestData) throws Exception {
		String url = baseUrl+"/${Req_id}";
		String header = "Accept=application/json";
		Response response = cf.SendRequest("GET", null, header, getBookingTestData, null, url);
		return response;
	}
	
	/**
	 * This method is to send request for PartialUpdateBooking service
	 * @param token : accepts token for authorization
	 * @param partialUpdateBookingData : accepts the test data in key,value pairs and Key should starts with Req_
	 * @return Response object
	 * @throws Exception
	 */
	public Response sendRequestForPartialUpdateBooking(String token, Map<String, String> partialUpdateBookingData ) throws Exception {
		String url = baseUrl+"/${Req_id}";
		String header = "Content-Type=application/json,Accept=application/json";
		Response response = cf.SendRequest("PATCH", token, header, partialUpdateBookingData, "partialUpdateBooking.json", url);
		return response;
	}
	
	/**
	 * This method is to send request for GetBookingIds service
	 * @param getBookingTestData : accepts the test data in key,value pairs and Key should starts with Req_
	 * @return Response object
	 * @throws Exception
	 */
	public Response sendRequestForGetBookingIds(Map<String, String> getBookingTestData) throws Exception {
		Response response = null;
		if(getBookingTestData==null) {
			response = cf.SendRequest("GET", null, null, null, null, baseUrl);
		}
		else {
			String url = baseUrl+"?${Req_param_1}=${Req_value_1}&${Req_param_2}=${Req_value_2}";
			response = cf.SendRequest("GET", null, null, getBookingTestData, null, url);
		}
		return response;
	}
	
	/**
	 * This method is to send request for DeleteBooking service
	 * @param token : accepts token for authorization
	 * @param deleteBookingData : accepts the test data in key,value pairs and Key should starts with Req_
	 * @return Response object
	 * @throws Exception
	 */
	public Response sendRequestForDeleteBooking(String token, Map<String, String> deleteBookingData ) throws Exception {
		String url = baseUrl+"/${Req_id}";
		Response response = cf.SendRequest("DELETE", token, null, deleteBookingData, null, url);
		return response;
	}

}
